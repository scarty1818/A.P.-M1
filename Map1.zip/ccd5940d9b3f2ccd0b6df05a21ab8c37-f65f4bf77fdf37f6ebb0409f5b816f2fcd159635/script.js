// Initialize the map with a given center and zoom level
var map = L.map('map', {
    center: [38.79067602900888, -90.47923106215619],
    zoom: 16
});

// Add a tile layer to the map
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Define an icon for the markers
var customIcon = L.icon({
    iconUrl: 'path/to/your/custom/icon.png',
    iconSize: [32, 37], // optional: set the size of the icon
    iconAnchor: [16, 37], // optional: set the point of the icon that corresponds to the marker's location
    popupAnchor: [0, -37] // optional: set the point from which the popup should open relative to the iconAnchor
});

// Add five markers with custom popups

var marker1 = L.marker([38.79094275623704, -90.47764836657578]).addTo(map);
marker1.bindPopup("<b>Restaurant 1</b><br>La Belle Vie").openPopup();

var marker2 = L.marker([38.79138125689113, -90.47731419594638]).addTo(map);
marker2.bindPopup("<b>Restaurant 2</b><br>Course Coffee Roasters").openPopup();

var marker3 = L.marker([38.79187990278788, -90.47706385604162]).addTo(map);
marker3.bindPopup("<b>Restaurant 3</b><br>Bike Stop Bakery").openPopup();

var marker4 = L.marker([38.790766978165095, -90.47795858940495]).addTo(map);
marker4.bindPopup("<b>Restaurant 4</b><br>Le Good News Brewery").openPopup();

var marker5 = L.marker([38.788365651199236, -90.47892329578266]).addTo(map);
marker5.bindPopup("<b>Restaurant 5</b><br>Sha's Coffee Bean").openPopup();